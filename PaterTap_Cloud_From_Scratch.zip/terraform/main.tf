terraform {
  required_version = ">= 1.6.0"
  required_providers {
    yandex = {
      source = "yandex-cloud/yandex"
    }
  }
}

# Scaffold only: no cloud resources are created yet.
# Implement the chosen Yandex Cloud architecture, then validate it against
# the current official provider docs before any terraform apply.
