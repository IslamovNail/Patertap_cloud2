variable "cloud_id" { type = string; description = "Yandex Cloud ID" }
variable "folder_id" { type = string; description = "Yandex Cloud folder ID" }
variable "region" { type = string; default = "ru-central1" }
variable "environment" { type = string; default = "demo" }
