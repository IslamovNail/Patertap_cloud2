# PaterTap Cloud — fresh starter

This is a separate starter project. It does not overwrite the old PaterTap or Render deployment.

## Run locally (computer)
1. Install Python 3.11+.
2. `pip install -r requirements.txt`
3. `python app.py`
4. Open http://127.0.0.1:5000

The cloud configuration is currently a scaffold, not a deployed infrastructure. Do not apply Terraform until the real resources have been implemented and validated. See `docs/setup-guide.md`.
