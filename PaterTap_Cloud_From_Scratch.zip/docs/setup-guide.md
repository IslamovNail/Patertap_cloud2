# Setup guide

## Phone-first workflow
Keep this ZIP separate from the old project. If using GitHub from a mobile browser, create a new repository for this project; do not overwrite the old repository. A computer is strongly recommended for running tests and deploying Terraform. GitHub Codespaces may be an option if available to your account.

## Local run (computer)
Install Python 3.11+, run `pip install -r requirements.txt`, then `python app.py`. Open `http://127.0.0.1:5000` and check `/healthz`.

## AI
Set `GEMINI_API_KEY` as a server environment variable. Do not place it in HTML, JavaScript, GitHub, screenshots or chat. AI is not live until configured and tested.

## Cloud cost
The course PDF recommends Yandex Cloud. Its official free-tier documentation explains that monthly quotas are limited and usage beyond them may be billed:
https://yandex.cloud/ru-kz/docs/billing/concepts/serverless-free-tier
Review current pricing before creating any resource. Do not deploy until Terraform is implemented, validated and the plan is reviewed.
