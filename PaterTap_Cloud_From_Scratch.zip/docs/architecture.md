# Architecture

- Frontend: responsive HTML/CSS/JavaScript.
- Backend: Flask API.
- Starter persistence: SQLite for local/demo use only.
- AI: optional Gemini API called server-side; the API key must remain secret.
- Health check: `/healthz`.

## Proposed cloud design
The assignment asks for at least four cloud services, Terraform, AI inference, networking, compute, storage/database and IAM. Proposed Yandex Cloud components are API Gateway, Cloud Functions or Serverless Containers, Object Storage, Managed YDB, IAM, VPC and Cloud Logging/Monitoring. Final resource design must be implemented and validated against the current provider before deployment.

## Security and limitations
Listings and roommate profiles are fictional demo data. Do not use this starter for real personal data without authentication, authorization, input protections, backups and managed persistence. Never commit secrets or Terraform state.
