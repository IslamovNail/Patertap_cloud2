# 10-minute demo

1. Explain the student housing problem (1 min).
2. Filter sample listings by city and budget (2 min).
3. Change roommate preferences and compare compatibility estimates (2 min).
4. Show `/healthz` and explain monitoring (1 min).
5. Show the AI assistant only after a real response is tested (2 min).
6. Explain the cloud architecture and data flow (1 min).
7. Show Terraform, cost controls and security limits (1 min).

Do not claim cloud deployment or live AI unless tested.
